<?php

namespace App\Traits;

use App\Models\LogAktifitas;
use Illuminate\Support\Facades\Auth;

trait LogsActivity {
    protected static function bootLogsActivity() {
        static::created(fn($model) => $model->saveLog('Tambah'));
        static::updated(fn($model) => $model->saveLog('Update'));
        static::deleted(fn($model) => $model->saveLog('Hapus'));
    }

    protected function saveLog($action) {
        LogAktifitas::create([
            'user_id' => Auth::id() ?? 1,
            'aktifitas' => "$action " . class_basename($this) . " (ID: {$this->id})", // Sesuai kolom migrasi
        ]);
    }
}