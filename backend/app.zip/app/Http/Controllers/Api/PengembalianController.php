<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Pengembalian;
use App\Models\Peminjaman;
use App\Models\Alat;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class PengembalianController extends Controller
{
    /**
     * Menampilkan daftar semua pengembalian (Admin/Petugas).
     */
    public function index()
    {
        // FIX: peminjamans → peminjaman
        $data = Pengembalian::with(['peminjaman.user', 'peminjaman.alat', 'kategori'])
            ->latest()
            ->get();
        
        return response()->json($data);
    }

    /**
     * Proses pengembalian barang dan update stok.
     */
    public function store(Request $request)
    {
        $request->validate([
            'peminjaman_id'           => 'required|exists:peminjamans,id|unique:pengembalians,peminjaman_id',
            'tgl_pengembalian_aktual' => 'required|date',
            'status'                  => 'required|in:baik,rusak_ringan,rusak_berat,hancur,hilang',
            'catatan'                 => 'nullable|string',
        ]);

        DB::beginTransaction();
        
        try {
            // 1. Ambil data peminjaman
            $peminjaman = Peminjaman::with('alat')->findOrFail($request->peminjaman_id);

            // Cek status peminjaman
            if ($peminjaman->status !== 'disetujui') {
                return response()->json([
                    'message' => 'Hanya peminjaman dengan status "disetujui" yang bisa dikembalikan.'
                ], 400);
            }

            // 2. LOCK data alat untuk mencegah race condition
            $alat = Alat::where('id', $peminjaman->alat_id)->lockForUpdate()->first();

            // 3. Hitung Denda
            $tglSeharusnya = Carbon::parse($peminjaman->tgl_pengembalian);
            $tglAktual     = Carbon::parse($request->tgl_pengembalian_aktual);
            
            $denda = 0;
            if ($tglAktual->gt($tglSeharusnya)) {
                $selisihHari = $tglAktual->diffInDays($tglSeharusnya);
                $denda = $selisihHari * 5000; // Rp 5.000 per hari
            }

            // 4. Simpan data pengembalian
            $pengembalian = Pengembalian::create([
                'peminjaman_id'           => $request->peminjaman_id,
                'kategori_id'             => $peminjaman->kategori_id,
                'tgl_pengembalian_aktual' => $request->tgl_pengembalian_aktual,
                'denda'                   => $denda,
                'status'                  => $request->status,
                'catatan'                 => $request->catatan ?? 'Tidak ada catatan',
            ]);

            // 5. Update status peminjaman
            $peminjaman->update(['status' => 'selesai']);

            // 6. Kembalikan stok alat
            $alat->increment('stok', $peminjaman->jumlah);

            DB::commit();

            return response()->json([
                'message' => 'Pengembalian berhasil diproses. Stok alat telah diperbarui.',
                'denda'   => $denda,
                'data'    => $pengembalian->load(['peminjaman.alat', 'peminjaman.user'])
            ], 201);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'message' => 'Terjadi kesalahan: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Detail pengembalian tertentu.
     */
    public function show($id)
    {
        // FIX: peminjamans → peminjaman
        $pengembalian = Pengembalian::with(['peminjaman.user', 'peminjaman.alat', 'kategori'])
            ->findOrFail($id);
        
        return response()->json($pengembalian);
    }

    /**
     * Hapus data pengembalian.
     */
    public function destroy($id)
    {
        $pengembalian = Pengembalian::findOrFail($id);
        $pengembalian->delete();

        return response()->json(['message' => 'Data pengembalian berhasil dihapus.']);
    }
}