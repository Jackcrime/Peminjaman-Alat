import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

// Import Pages sesuai struktur folder baru kamu
import Login from './pages/auth/login';
import Register from './pages/auth/register';
import AdminDashboard from './pages/admin/dashboard';
import StaffDashboard from './pages/staff/dashboard'; // Asumsi folder 'staff' untuk petugas
import UserDashboard from './pages/user/dashboard';

// Import Component Satpam
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <Router>
      <Routes>
        {/* --- PUBLIC ROUTES --- */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        
        {/* Default Route: Redirect ke login kalau buka root */}
        <Route path="/" element={<Navigate to="/login" replace />} />


        {/* --- ADMIN ROUTES --- */}
        {/* Role di Backend: 'admin' */}
        <Route element={<ProtectedRoute allowedRoles={['admin']} />}>
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          {/* Nanti tambah route admin lain di sini, misal /admin/users */}
        </Route>


        {/* --- STAFF (PETUGAS) ROUTES --- */}
        {/* Role di Backend: 'petugas' */}
        <Route element={<ProtectedRoute allowedRoles={['petugas', 'admin']} />}> 
          {/* Note: Admin gue masukin juga biar Admin bisa ngintip dashboard staff kalau perlu */}
          <Route path="/staff/dashboard" element={<StaffDashboard />} />
        </Route>


        {/* --- USER (PEMINJAM) ROUTES --- */}
        {/* Role di Backend: 'peminjam' */}
        <Route element={<ProtectedRoute allowedRoles={['peminjam']} />}>
          <Route path="/user/dashboard" element={<UserDashboard />} />
        </Route>


        {/* --- 404 / CATCH ALL --- */}
        <Route path="*" element={<div>Halaman tidak ditemukan (404)</div>} />
      </Routes>
    </Router>
  );
}

export default App;