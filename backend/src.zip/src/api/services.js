// src/api/services.js
import axiosClient from './axiosClient';

export const alatApi = {
  // --- ALAT (Public/User) ---
  getAll: () => axiosClient.get('/katalog-alat'), // User biasa
  
  // --- ALAT (Admin CRUD) ---
  adminGetAll: () => axiosClient.get('/alats'), // Admin Table
  create: (data) => axiosClient.post('/alats', data),
  update: (id, data) => axiosClient.put(`/alats/${id}`, data),
  delete: (id) => axiosClient.delete(`/alats/${id}`),
};

export const peminjamanApi = {
  // Siswa
  getHistory: () => axiosClient.get('/peminjaman/history'),
  ajukan: (data) => axiosClient.post('/peminjaman/ajukan', data),

  // Petugas/Admin
  getAllRequest: () => axiosClient.get('/peminjaman/all'),
  updateStatus: (id, status) => axiosClient.put(`/peminjaman/${id}/status`, { status }), // status: 'disetujui'/'ditolak'
};

export const pengembalianApi = {
  // Petugas Input Barang Balik
  processReturn: (data) => axiosClient.post('/pengembalian', data),
};

export const dashboardApi = {
  getStats: () => axiosClient.get('/dashboard'),
};