import axiosClient from './axiosClient';

export const authApi = {
    login: async (email, password) => {
        const response = await axiosClient.post('/auth/login', { email, password });
        return response.data;
    },

    register: async (data) => {
        return await axiosClient.post('auth/register', data);
    },

    logout: async () => {
        return await axiosClient.post('auth/logout');
    },

    getMe: async () => {
        return await axiosClient.get('/me');
    }
}