import { Navigate, useNavigate, Outlet } from 'react-router-dom';

const ProtectedRoute = ({ allowedRoles }) => {
  const token = localStorage.getItem('ACCESS_TOKEN');
  const userString = localStorage.getItem('USER_DATA');
  const user = userString ? JSON.parse(userString) : null;

  // 1. Cek Login: Kalau gak ada token, tendang ke login
  if (!token) {
    return <Navigate to="/login" replace />;
  }

  // 2. Cek Role: Kalau role user gak ada di daftar allowedRoles, tendang ke dashboard masing-masing atau unauthorized
  if (allowedRoles && !allowedRoles.includes(user?.role)) {
    // Logic redirect pintar: balikin ke habitat aslinya
    if (user.role === 'admin') return <Navigate to="/admin/dashboard" replace />;
    if (user.role === 'petugas') return <Navigate to="/staff/dashboard" replace />;
    if (user.role === 'peminjam') return <Navigate to="/user/dashboard" replace />;
    
    return <Navigate to="/login" replace />;
  }

  // Lolos seleksi? Silakan masuk
  return <Outlet />;
};

export default ProtectedRoute;