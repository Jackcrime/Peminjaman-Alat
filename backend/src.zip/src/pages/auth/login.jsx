import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { authApi } from '../../api/auth'; // Pastikan path import ini benar

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');

    try {
      // 1. Tembak API Login Laravel
      const response = await authApi.login(email, password);
      
      // 2. Simpan Token & User Data (PENTING BUAT PROTECTED ROUTE)
      localStorage.setItem('ACCESS_TOKEN', response.token);
      localStorage.setItem('USER_DATA', JSON.stringify(response.user));

      // 3. Cek Role & Redirect ke Dashboard yang sesuai folder
      const role = response.user.role; // admin, petugas, atau peminjam

      if (role === 'admin') {
        navigate('/admin/dashboard');
      } else if (role === 'petugas') {
        navigate('/staff/dashboard'); // Folder kamu namanya 'staff'
      } else if (role === 'peminjam') {
        navigate('/user/dashboard');
      } else {
        setError('Role tidak dikenali');
      }

    } catch (err) {
      console.error(err);
      setError('Login gagal! Periksa email dan password.');
    }
  };

  return (
    <div className="flex justify-center items-center h-screen bg-gray-100">
      <form onSubmit={handleLogin} className="p-8 bg-white rounded shadow-md w-96">
        <h2 className="text-2xl font-bold mb-4 text-center">Login Inventaris</h2>
        
        {error && <div className="bg-red-100 text-red-700 p-2 mb-4 rounded">{error}</div>}

        <div className="mb-4">
          <label className="block text-sm font-medium mb-1">Email</label>
          <input 
            type="email" 
            className="w-full border rounded p-2" 
            value={email} 
            onChange={(e) => setEmail(e.target.value)} 
            required 
          />
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium mb-1">Password</label>
          <input 
            type="password" 
            className="w-full border rounded p-2" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
            required 
          />
        </div>

        <button type="submit" className="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700">
          Masuk
        </button>
      </form>
    </div>
  );
};

export default Login;