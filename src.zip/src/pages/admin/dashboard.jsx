import React from 'react';

const Dashboard = () => {
  // Ambil data user dari LocalStorage
  const user = JSON.parse(localStorage.getItem('USER_DATA'));

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Dashboard {user.role === 'admin' ? 'Administrator' : 'staff'}</h1>
      
      {/* Konten Umum (Dua-duanya lihat) */}
      <div className="stats shadow mt-4 w-full">
        <div className="stat">
          <div className="stat-title">Peminjaman Aktif</div>
          <div className="stat-value">12</div>
        </div>
      </div>

      {/* Konten KHUSUS ADMIN (Petugas gak liat ini) */}
      {user.role === 'admin' && (
        <div className="mt-10 p-4 bg-red-100 rounded-lg">
          <h2 className="font-bold text-red-700">Admin Only Zone</h2>
          <p>Tombol hapus user, kelola master data alat, dll ada disini.</p>
        </div>
      )}
    </div>
  );
};

export default Dashboard;