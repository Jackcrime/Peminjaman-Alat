import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { authApi } from '../../api/auth';

const Register = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    password_confirmation: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const { data } = await authApi.register(formData);
      
      // Otomatis login setelah register
      if (data.token) {
        localStorage.setItem('ACCESS_TOKEN', data.token);
        localStorage.setItem('USER_DATA', JSON.stringify(data.user));
        
        // FIX: Redirect based on role (user, staff, admin)
        if (data.user.role === 'user') {
          navigate('/user/dashboard');
        } else if (data.user.role === 'staff' || data.user.role === 'admin') {
          navigate('/dashboard');
        } else {
          navigate('/unauthorized');
        }
      } else {
        // Jika tidak auto-login, redirect ke halaman login
        navigate('/login');
      }
      
    } catch (err) {
      setError(err.response?.data?.message || 'Register gagal');
      console.error('Register error:', err.response?.data);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-base-200 flex items-center justify-center p-4">
      <div className="card w-full max-w-md bg-base-100 shadow-2xl border-t-8 border-primary">
        <div className="card-body">
          <h2 className="text-3xl font-black italic text-center text-primary mb-6">REGISTER</h2>
          
          {error && (
            <div className="alert alert-error text-xs mb-4">
              <span>{error}</span>
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="form-control">
              <input
                type="text"
                name="name"
                placeholder="Nama Lengkap"
                className="input input-bordered w-full"
                value={formData.name}
                onChange={handleChange}
                required
                disabled={loading}
              />
            </div>
            
            <div className="form-control">
              <input
                type="email"
                name="email"
                placeholder="Email"
                className="input input-bordered w-full"
                value={formData.email}
                onChange={handleChange}
                required
                disabled={loading}
              />
            </div>
            
            <div className="form-control">
              <input
                type="password"
                name="password"
                placeholder="Password"
                className="input input-bordered w-full"
                value={formData.password}
                onChange={handleChange}
                required
                disabled={loading}
              />
            </div>
            
            <div className="form-control">
              <input
                type="password"
                name="password_confirmation"
                placeholder="Konfirmasi Password"
                className="input input-bordered w-full"
                value={formData.password_confirmation}
                onChange={handleChange}
                required
                disabled={loading}
              />
            </div>
            
            <button
              type="submit"
              className={`btn btn-primary w-full ${loading ? 'loading' : ''}`}
              disabled={loading}
            >
              {loading ? 'MEMPROSES...' : 'DAFTAR'}
            </button>
          </form>
          
          <p className="text-center text-xs mt-4">
            Sudah punya akun?{' '}
            <Link to="/login" className="link link-primary font-bold">
              Login
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Register;