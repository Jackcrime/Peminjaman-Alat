import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { authApi } from '../../api/auth';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    
    try {
      const { data } = await authApi.login(email, password);
      
      // Simpan token & user data
      localStorage.setItem('ACCESS_TOKEN', data.token);
      localStorage.setItem('USER_DATA', JSON.stringify(data.user));
      
      // FIX: Redirect based on role (user, staff, admin)
      if (data.user.role === 'user') {
        navigate('/user/dashboard');
      } else if (data.user.role === 'staff' || data.user.role === 'admin') {
        navigate('/dashboard');
      } else {
        // Fallback jika role tidak dikenali
        navigate('/unauthorized');
      }
      
    } catch (err) {
      setError(err.response?.data?.message || 'Login Gagal');
      console.error('Login error:', err.response?.data);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-base-200 flex items-center justify-center p-4">
      <div className="card w-full max-w-md bg-base-100 shadow-2xl border-t-8 border-primary">
        <div className="card-body">
          <h2 className="text-3xl font-black italic text-center text-primary mb-6">LOGIN</h2>
          
          {error && (
            <div className="alert alert-error text-xs mb-4">
              <span>{error}</span>
            </div>
          )}
          
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="form-control">
              <input
                type="email"
                placeholder="Email"
                className="input input-bordered w-full"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                disabled={loading}
              />
            </div>
            
            <div className="form-control">
              <input
                type="password"
                placeholder="Password"
                className="input input-bordered w-full"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                disabled={loading}
              />
            </div>
            
            <button
              type="submit"
              className={`btn btn-primary w-full ${loading ? 'loading' : ''}`}
              disabled={loading}
            >
              {loading ? 'MEMPROSES...' : 'MASUK'}
            </button>
          </form>
          
          <p className="text-center text-xs mt-4">
            Belum punya akun?{' '}
            <Link to="/register" className="link link-primary font-bold">
              Daftar
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;