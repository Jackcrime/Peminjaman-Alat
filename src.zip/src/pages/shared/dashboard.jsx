import React, { useEffect, useState } from 'react';
import { dashboardApi } from '../../api/services';
import { Package, Clock, CheckCircle2, Users } from 'lucide-react';

const Dashboard = () => {
  const [stats, setStats] = useState({ total_alat: 0, pending_approval: 0, pinjaman_aktif: 0, total_peminjam: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    dashboardApi.getStats()
      .then(res => setStats(res.data))
      .catch(e => console.error(e))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="h-96 flex items-center justify-center"><span className="loading loading-spinner loading-lg text-primary"></span></div>;

  return (
    <div>
      <h1 className="text-3xl font-black italic tracking-tighter uppercase mb-8">Ringkasan Sistem</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard color="border-blue-600" icon={<Package />} title="Aset Alat" value={stats.total_alat} />
        <StatCard color="border-yellow-500" icon={<Clock />} title="Pending" value={stats.pending_approval} isAlert />
        <StatCard color="border-green-600" icon={<CheckCircle2 />} title="Aktif Pinjam" value={stats.pinjaman_aktif} />
        <StatCard color="border-purple-600" icon={<Users />} title="Total Siswa" value={stats.total_peminjam} />
      </div>
    </div>
  );
};

const StatCard = ({ color, icon, title, value, isAlert }) => (
  <div className={`bg-white p-6 rounded-3xl shadow-xl border-b-8 ${color}`}>
    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-4 bg-base-100 ${isAlert ? 'text-yellow-600' : 'text-primary'}`}>{icon}</div>
    <div className="text-xs font-bold opacity-40 uppercase">{title}</div>
    <div className="text-4xl font-black tracking-tighter">{value}</div>
  </div>
);

export default Dashboard;