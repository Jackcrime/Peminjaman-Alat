import React from 'react';
import { useNavigate } from 'react-router-dom';

const UserDashboard = () => {
  const user = JSON.parse(localStorage.getItem('USER_DATA') || '{}');
  const navigate = useNavigate();

  const logout = () => {
    localStorage.clear();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-base-200 p-8 flex flex-col items-center justify-center">
      <div className="card w-full max-w-2xl bg-base-100 shadow-xl">
        <div className="card-body">
          <h1 className="text-3xl font-black italic">HALO, {user.name}!</h1>
          <p className="opacity-70">Selamat datang di Sistem Peminjaman Alat Sekolah.</p>
          <div className="divider"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <button className="btn btn-primary">Lihat Katalog Alat</button>
            <button className="btn btn-outline">Riwayat Pinjaman</button>
          </div>
          <button onClick={logout} className="btn btn-error btn-ghost mt-10">Keluar</button>
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;