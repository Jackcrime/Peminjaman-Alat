import axiosClient from './axiosClient';

export const authApi = {
  // Login ke Laravel (TANPA CSRF)
  login: (email, password) => {
    return axiosClient.post('/login', { email, password });
  },
  
  // Register User baru (TANPA CSRF)
  register: (data) => {
    return axiosClient.post('/register', data);
  },
  
  // Logout & hapus token di server
  logout: () => axiosClient.post('/logout'),
  
  // Ambil data user yang sedang login
  getMe: () => axiosClient.get('/me'),
};