import axiosClient from './axiosClient';

export const dashboardApi = {
  // Ambil statistik untuk Dashboard (Shared)
  getStats: () => axiosClient.get('/dashboard'),
};

export const alatApi = {
  // Ambil semua data alat
  getAll: () => axiosClient.get('/alats'),
  
  // Tambah alat baru
  store: (data) => axiosClient.post('/alats', data),
  
  // Update data alat
  update: (id, data) => axiosClient.put(`/alats/${id}`, data),
  
  // Hapus alat
  delete: (id) => axiosClient.delete(`/alats/${id}`),
};