import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';

// Import Pages
import Login from './pages/auth/login';
import Register from './pages/auth/register';
import Dashboard from './pages/shared/dashboard';
import UserDashboard from './pages/user/dashboard';

// Import Components
import Layout from './components/Layout';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  const isAuthenticated = () => {
    return !!localStorage.getItem('ACCESS_TOKEN');
  };

  const getDefaultRoute = () => {
    const userData = localStorage.getItem('USER_DATA');
    if (!userData) return '/login';
    
    const user = JSON.parse(userData);
    if (user.role === 'user') return '/user/dashboard';
    if (user.role === 'admin' || user.role === 'staff') return '/dashboard';
    return '/login';
  };

  return (
    <Router>
      <Routes>
        {/* RUTE PUBLIK */}
        <Route 
          path="/login" 
          element={isAuthenticated() ? <Navigate to={getDefaultRoute()} replace /> : <Login />} 
        />
        <Route 
          path="/register" 
          element={isAuthenticated() ? <Navigate to={getDefaultRoute()} replace /> : <Register />} 
        />

        {/* RUTE STAFF & ADMIN */}
        <Route element={<ProtectedRoute allowedRoles={['admin', 'staff']} />}>
          <Route element={<Layout />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route 
              path="/peminjaman" 
              element={
                <div className="font-black text-3xl italic p-4 uppercase tracking-tighter">
                  Halaman Daftar Peminjaman
                </div>
              } 
            />
            <Route 
              path="/pengembalian" 
              element={
                <div className="font-black text-3xl italic p-4 uppercase tracking-tighter">
                  Halaman Pengembalian Alat
                </div>
              } 
            />
            
            {/* KHUSUS ADMIN */}
            <Route element={<ProtectedRoute allowedRoles={['admin']} />}>
              <Route 
                path="/alats" 
                element={
                  <div className="font-black text-3xl italic p-4 uppercase tracking-tighter text-primary">
                    Master Data Aset Alat
                  </div>
                } 
              />
              <Route 
                path="/users" 
                element={
                  <div className="font-black text-3xl italic p-4 uppercase tracking-tighter text-primary">
                    Manajemen User Sistem
                  </div>
                } 
              />
              <Route 
                path="/logs" 
                element={
                  <div className="font-black text-3xl italic p-4 uppercase tracking-tighter text-primary">
                    Audit Log Aktivitas
                  </div>
                } 
              />
            </Route>
          </Route>
        </Route>

        {/* RUTE USER (Peminjam/Siswa) */}
        <Route element={<ProtectedRoute allowedRoles={['user']} />}>
          <Route path="/user/dashboard" element={<UserDashboard />} />
        </Route>

        {/* ERROR & DEFAULT */}
        <Route 
          path="/unauthorized" 
          element={
            <div className="h-screen flex items-center justify-center font-black text-error text-4xl italic uppercase tracking-tighter bg-error/5">
              <div className="text-center">
                <p className="mb-4">Akses Ditolak!</p>
                <Link to="/login" className="btn btn-primary">
                  Kembali ke Login
                </Link>
              </div>
            </div>
          } 
        />
        
        <Route path="/" element={<Navigate to={getDefaultRoute()} replace />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </Router>
  );
}

export default App;