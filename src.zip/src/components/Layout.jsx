import React from 'react';
import { Link, useLocation, useNavigate, Outlet } from 'react-router-dom';
import { authApi } from '../api/auth';
import { 
  LayoutDashboard, Package, Users, ClipboardList, 
  LogOut, History, Settings, Menu 
} from 'lucide-react';

const Layout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const user = JSON.parse(localStorage.getItem('USER_DATA') || '{}');

  const handleLogout = async () => {
    try { 
      await authApi.logout(); 
    } catch (e) {
      console.error('Logout error:', e);
    }
    localStorage.clear();
    navigate('/login');
  };

  const isActive = (path) => location.pathname === path ? 'active bg-primary text-white' : '';

  return (
    <div className="drawer lg:drawer-open font-sans">
      <input id="my-drawer" type="checkbox" className="drawer-toggle" />
      
      <div className="drawer-content flex flex-col bg-base-200 min-h-screen">
        <div className="navbar bg-base-100 lg:hidden shadow-sm">
          <label htmlFor="my-drawer" className="btn btn-square btn-ghost">
            <Menu />
          </label>
          <div className="flex-1 px-2 font-bold italic">SARPRAS</div>
        </div>
        <div className="p-4 lg:p-8">
          <Outlet />
        </div>
      </div>
      
      <div className="drawer-side">
        <label htmlFor="my-drawer" className="drawer-overlay"></label>
        <ul className="menu p-4 w-72 min-h-full bg-base-100 text-base-content border-r border-base-300">
          <li className="mb-10 px-2 font-black italic text-2xl text-primary">
            INVENTARIS
          </li>
          
          <li className="menu-title opacity-40 uppercase text-xs font-bold">
            Menu Utama
          </li>
          <li>
            <Link to="/dashboard" className={isActive('/dashboard')}>
              <LayoutDashboard size={20}/> Dashboard
            </Link>
          </li>
          <li>
            <Link to="/peminjaman" className={isActive('/peminjaman')}>
              <ClipboardList size={20}/> Peminjaman
            </Link>
          </li>
          <li>
            <Link to="/pengembalian" className={isActive('/pengembalian')}>
              <History size={20}/> Pengembalian
            </Link>
          </li>
          
          {/* KHUSUS ADMIN */}
          {user.role === 'admin' && (
            <>
              <li className="menu-title opacity-40 uppercase text-xs font-bold mt-6">
                Master Data
              </li>
              <li>
                <Link to="/alats" className={isActive('/alats')}>
                  <Package size={20}/> Data Alat
                </Link>
              </li>
              <li>
                <Link to="/users" className={isActive('/users')}>
                  <Users size={20}/> Manajemen User
                </Link>
              </li>
              <li>
                <Link to="/logs" className={isActive('/logs')}>
                  <Settings size={20}/> Audit Log
                </Link>
              </li>
            </>
          )}
          
          <div className="mt-auto">
            <div className="bg-base-200 p-4 rounded-xl mb-4 text-xs">
              <div className="opacity-50 font-bold">LOGIN SEBAGAI:</div>
              <div className="font-bold truncate">{user.name || 'Guest'}</div>
              <div className="badge badge-primary badge-outline mt-1 uppercase">
                {user.role || 'N/A'}
              </div>
            </div>
            <li>
              <button onClick={handleLogout} className="text-error font-bold">
                <LogOut size={20}/> Keluar
              </button>
            </li>
          </div>
        </ul>
      </div>
    </div>
  );
};

export default Layout;