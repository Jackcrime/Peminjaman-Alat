import { Navigate, Outlet } from 'react-router-dom';

const ProtectedRoute = ({ allowedRoles }) => {
  const token = localStorage.getItem('ACCESS_TOKEN');
  const userData = localStorage.getItem('USER_DATA');
  
  // Cek login
  if (!token) {
    return <Navigate to="/login" replace />;
  }
  
  // Cek role jika ada allowedRoles
  if (allowedRoles && userData) {
    const user = JSON.parse(userData);
    
    if (!allowedRoles.includes(user.role)) {
      return <Navigate to="/unauthorized" replace />;
    }
  }
  
  return <Outlet />;
};

export default ProtectedRoute;