import { Navigate, Outlet } from 'react-router-dom';

const ProtectedRoute = ({ allowedRoles }) => {
  const token = localStorage.getItem('ACCESS_TOKEN');
  const user = JSON.parse(localStorage.getItem('USER_DATA'));

  if (!token) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user?.role)) {
    // Redirect ke dashboard masing-masing sesuai role
    if (user.role === 'admin') return <Navigate to="/admin/dashboard" replace />;
    if (user.role === 'petugas') return <Navigate to="/staff/dashboard" replace />;
    if (user.role === 'peminjam') return <Navigate to="/user/dashboard" replace />;
    
    return <Navigate to="/login" replace />;
  }

  return <Outlet />;
};

export default ProtectedRoute;