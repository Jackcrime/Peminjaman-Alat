import { useState, useEffect } from 'react';
import { pengembalianService } from '../../../api/services';
import { 
  RotateCcw, 
  Search,
  Calendar,
  Package,
  AlertCircle,
  CheckCircle,
  FileText,
  FileSpreadsheet
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';

const Pengembalian = () => {
  const [pengembalian, setPengembalian] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await pengembalianService.getAll();
      setPengembalian(Array.isArray(res.data) ? res.data : []);
    } catch (error) {
      console.error('Error:', error);
      setError('Gagal memuat data');
      setPengembalian([]);
    } finally {
      setLoading(false);
    }
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    
    doc.setFontSize(18);
    doc.text('Laporan Pengembalian Alat', 14, 22);
    
    doc.setFontSize(11);
    doc.text(`Tanggal: ${new Date().toLocaleDateString('id-ID')}`, 14, 30);
    
    const tableData = filteredData.map((item, index) => [
      index + 1,
      item.peminjaman?.user?.name || 'N/A',
      item.peminjaman?.alat?.nama_alat || 'N/A',
      item.peminjaman?.jumlah || 0,
      item.tgl_pengembalian ? new Date(item.tgl_pengembalian).toLocaleDateString('id-ID') : '-',
      item.kondisi_kembali || 'Baik'
    ]);
    
    autoTable(doc, {
      head: [['No', 'Peminjam', 'Alat', 'Jumlah', 'Tgl Kembali', 'Kondisi']],
      body: tableData,
      startY: 36,
      styles: { fontSize: 9 },
      headStyles: { fillColor: [139, 92, 246] }
    });
    
    doc.save(`pengembalian-${new Date().getTime()}.pdf`);
  };

  const exportToExcel = () => {
    const excelData = filteredData.map((item, index) => ({
      'No': index + 1,
      'Peminjam': item.peminjaman?.user?.name || 'N/A',
      'Email': item.peminjaman?.user?.email || 'N/A',
      'Alat': item.peminjaman?.alat?.nama_alat || 'N/A',
      'Kode Alat': item.peminjaman?.alat?.kode_alat || 'N/A',
      'Jumlah': item.peminjaman?.jumlah || 0,
      'Tanggal Pinjam': item.peminjaman?.tgl_peminjaman 
        ? new Date(item.peminjaman.tgl_peminjaman).toLocaleDateString('id-ID')
        : '-',
      'Tanggal Kembali': item.tgl_pengembalian 
        ? new Date(item.tgl_pengembalian).toLocaleDateString('id-ID')
        : '-',
      'Kondisi': item.kondisi_kembali || 'Baik',
      'Catatan': item.catatan || '-'
    }));
    
    const ws = XLSX.utils.json_to_sheet(excelData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Pengembalian');
    
    XLSX.writeFile(wb, `pengembalian-${new Date().getTime()}.xlsx`);
  };

  const filteredData = pengembalian.filter((item) =>
    item.peminjaman?.user?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.peminjaman?.alat?.nama_alat?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="flex flex-col items-center gap-3">
          <div className="loading loading-spinner loading-lg text-blue-600"></div>
          <p className="text-gray-600">Memuat data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Pengembalian Alat</h1>
              <p className="text-gray-500 mt-1">Kelola data pengembalian alat</p>
            </div>
            <div className="flex gap-2">
              <button 
                onClick={exportToPDF}
                className="btn bg-rose-600 hover:bg-rose-700 text-white border-none"
              >
                <FileText className="w-5 h-5" />
                Export PDF
              </button>
              <button 
                onClick={exportToExcel}
                className="btn bg-emerald-600 hover:bg-emerald-700 text-white border-none"
              >
                <FileSpreadsheet className="w-5 h-5" />
                Export Excel
              </button>
            </div>
          </div>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="alert alert-error bg-rose-50 border-rose-200 text-rose-700">
            <AlertCircle className="w-5 h-5" />
            <span>{error}</span>
          </div>
        )}

        {/* Stats */}
        <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
          <div className="flex items-center gap-3">
            <div className="bg-purple-100 p-3 rounded-lg">
              <RotateCcw className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Total Pengembalian</p>
              <p className="text-2xl font-bold text-gray-900">{pengembalian.length}</p>
            </div>
          </div>
        </div>

        {/* Search Bar */}
        <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Cari berdasarkan peminjam atau alat..."
              className="input input-bordered w-full pl-10 bg-gray-50 border-gray-200 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="table w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-gray-700 font-semibold">Peminjam</th>
                  <th className="text-gray-700 font-semibold">Alat</th>
                  <th className="text-gray-700 font-semibold">Jumlah</th>
                  <th className="text-gray-700 font-semibold">Tgl Pinjam</th>
                  <th className="text-gray-700 font-semibold">Tgl Kembali</th>
                  <th className="text-gray-700 font-semibold">Kondisi</th>
                </tr>
              </thead>
              <tbody>
                {filteredData.length > 0 ? (
                  filteredData.map((item) => (
                    <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                      <td>
                        <div className="flex items-center gap-3">
                          <div className="avatar placeholder">
                            <div className="bg-purple-600 text-white rounded-full w-10 h-10 flex items-center justify-center">
                              <span className="text-sm font-semibold">
                                {item.peminjaman?.user?.name?.charAt(0).toUpperCase() || 'U'}
                              </span>
                            </div>
                          </div>
                          <div>
                            <div className="font-semibold text-gray-900">
                              {item.peminjaman?.user?.name || 'N/A'}
                            </div>
                            <div className="text-sm text-gray-500">
                              {item.peminjaman?.user?.kelas || ''}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td>
                        <div className="flex items-center gap-2">
                          <Package className="w-4 h-4 text-purple-600" />
                          <span className="font-semibold text-gray-900">
                            {item.peminjaman?.alat?.nama_alat || 'N/A'}
                          </span>
                        </div>
                      </td>
                      <td>
                        <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-700 border border-purple-200">
                          {item.peminjaman?.jumlah || 0} unit
                        </span>
                      </td>
                      <td>
                        <div className="flex items-center gap-2 text-gray-600 text-sm">
                          <Calendar className="w-4 h-4" />
                          {item.peminjaman?.tgl_peminjaman 
                            ? new Date(item.peminjaman.tgl_peminjaman).toLocaleDateString('id-ID')
                            : '-'}
                        </div>
                      </td>
                      <td>
                        <div className="flex items-center gap-2 text-gray-600 text-sm">
                          <Calendar className="w-4 h-4" />
                          {item.tgl_pengembalian 
                            ? new Date(item.tgl_pengembalian).toLocaleDateString('id-ID')
                            : '-'}
                        </div>
                      </td>
                      <td>
                        <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border ${
                          item.kondisi_kembali === 'baik' 
                            ? 'bg-emerald-100 text-emerald-700 border-emerald-200'
                            : 'bg-amber-100 text-amber-700 border-amber-200'
                        }`}>
                          {item.kondisi_kembali === 'baik' ? (
                            <CheckCircle className="w-3.5 h-3.5" />
                          ) : (
                            <AlertCircle className="w-3.5 h-3.5" />
                          )}
                          {item.kondisi_kembali || 'Baik'}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="text-center py-12">
                      <div className="flex flex-col items-center gap-2">
                        <RotateCcw className="w-12 h-12 text-gray-300" />
                        <p className="text-gray-500">Tidak ada data pengembalian</p>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Pengembalian;