import { useState, useEffect } from 'react';
import { logService } from '../../../api/services';

const LogAktifitas = () => {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const res = await logService.getAll();
      setLogs(res.data);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="flex justify-center items-center min-h-screen"><span className="loading loading-spinner loading-lg"></span></div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Log Aktifitas</h1>
        <p className="text-base-content/60">Riwayat aktivitas sistem</p>
      </div>

      <div className="card bg-base-100 shadow-xl">
        <div className="card-body p-0">
          <table className="table">
            <thead>
              <tr>
                <th>Waktu</th>
                <th>User</th>
                <th>Aktifitas</th>
              </tr>
            </thead>
            <tbody>
              {logs.map((log) => (
                <tr key={log.id}>
                  <td className="text-sm">{new Date(log.created_at).toLocaleString('id-ID')}</td>
                  <td className="font-semibold">{log.user?.name}</td>
                  <td>{log.aktifitas}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default LogAktifitas;