import { Link, useLocation } from 'react-router-dom';
import authService from '../../api/auth';

const Sidebar = ({ onClose }) => {
  const location = useLocation();
  const user = authService.getCurrentUser();

  const isActive = (path) => location.pathname.startsWith(path);

  // Menu berdasarkan role
  const getMenuItems = () => {
    const role = user?.role;

    if (role === 'admin') {
      return [
        { name: 'Dashboard', path: '/admin/dashboard', icon: '📊' },
        { divider: true, label: 'Master Data' },
        { name: 'Data Alat', path: '/admin/alat', icon: '🔧' },
        { name: 'Kategori', path: '/admin/kategori', icon: '📁' },
        { name: 'Lokasi', path: '/admin/lokasi', icon: '📍' },
        { name: 'Manajemen User', path: '/admin/users', icon: '👥' },
        { divider: true, label: 'Transaksi' },
        { name: 'Peminjaman', path: '/admin/peminjaman', icon: '📤' },
        { name: 'Pengembalian', path: '/admin/pengembalian', icon: '📥' },
        { divider: true, label: 'Lainnya' },
        { name: 'Log Aktifitas', path: '/admin/logs', icon: '📝' },
      ];
    } else if (role === 'staff') {
      return [
        { name: 'Dashboard', path: '/staff/dashboard', icon: '📊' },
        { divider: true, label: 'Transaksi' },
        { name: 'Peminjaman', path: '/staff/peminjaman', icon: '📤' },
        { name: 'Pengembalian', path: '/staff/pengembalian', icon: '📥' },
      ];
    } else {
      return [
        { name: 'Dashboard', path: '/user/dashboard', icon: '📊' },
        { name: 'Katalog Alat', path: '/user/katalog', icon: '📚' },
        { name: 'Riwayat Pinjam', path: '/user/riwayat', icon: '📋' },
      ];
    }
  };

  const menuItems = getMenuItems();

  return (
    <aside className="bg-base-100 w-80 min-h-screen shadow-xl">
      {/* Logo */}
      <div className="bg-primary text-primary-content p-4">
        <div className="flex items-center gap-3">
          <div className="avatar placeholder">
            <div className="bg-primary-focus text-primary-content rounded-lg w-12">
              <span className="text-2xl">🔧</span>
            </div>
          </div>
          <div>
            <h1 className="text-xl font-bold">InvenTrack</h1>
            <p className="text-xs opacity-80">Sistem Peminjaman Alat</p>
          </div>
        </div>
      </div>

      {/* User Info */}
      <div className="p-4 border-b border-base-300">
        <div className="flex items-center gap-3">
          <div className="avatar placeholder">
            <div className="bg-neutral text-neutral-content rounded-full w-12">
              <span className="text-xl">{user?.name?.charAt(0).toUpperCase()}</span>
            </div>
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-semibold truncate">{user?.name}</p>
            <div className="badge badge-sm badge-primary">{user?.role?.toUpperCase()}</div>
          </div>
        </div>
      </div>

      {/* Menu */}
      <ul className="menu p-4 space-y-1">
        {menuItems.map((item, index) => {
          if (item.divider) {
            return (
              <li key={index} className="menu-title">
                <span>{item.label}</span>
              </li>
            );
          }

          return (
            <li key={index}>
              <Link
                to={item.path}
                className={isActive(item.path) ? 'active' : ''}
                onClick={onClose}
              >
                <span className="text-lg">{item.icon}</span>
                <span>{item.name}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </aside>
  );
};

export default Sidebar;